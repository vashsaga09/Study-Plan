/*
  This is just a sample project for my Git crash course. It doesn't do anything.
*/

console.log('Task Tracker Running...');
